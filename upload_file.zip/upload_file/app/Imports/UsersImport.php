<?php

namespace App\Imports;

use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithStartRow;

class UsersImport implements ToCollection , WithStartRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function collection(Collection $rows)
    {
        $rows->each(function($row , $rowIdx) use(&$intervalles , &$items , &$not_founds)  {
            if($rowIdx == 0 || $rowIdx == 1){
                foreach ($row as $cellIdx => $value){
                    if($rowIdx == 0 && $cellIdx >= 2){
                        $intervalles[] = ['min' =>( $value ? $value : 0)];
                    }
                    if($rowIdx == 1 && $cellIdx >= 2){
                        $intervalles[$cellIdx - 2]['max'] = $value;
                        $intervalles[$cellIdx - 2]['originable_id'] = 1;
                        $intervalles[$cellIdx - 2]['originable_type'] = 'city';
                    }
                }
            }else{
                $destination = $this->idsMapper[$row[1]] ?? null;
                if(isset($destination)){
                    foreach ($row as $cellIdx => $value){
                        if($cellIdx >= 2){
                            $item =  $intervalles[$cellIdx - 2];
                            $item['destinationable_id'] = $destination;
                            $item['destinationable_type'] = eGridLocationType::_CITY;
                            $item['calcul_val'] = $value ? $value : -1;
                            $item['calcul_basis_id'] = $this->calculBasicId;
                            $item['type_val'] = eTaxeValType::_PRICE;
                            $item['rubric_id'] = 1;
                            $item['offerable_id'] = 1;
                            $item['offerable_type'] = "Grid";
                            $items[] = $item;
                        }
                    }
                }else{
                    $not_founds[] = $row[1];
                }                
            }
        }); 
    }

    public function startRow(): int
    {
        return 1;
    }
}
